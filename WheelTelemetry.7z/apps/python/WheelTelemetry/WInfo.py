import math
import ac
import acsys
import WConfig
import WLog

from sim_info import info


class WInfo:
    """ Tyre info to draw and update each tyre. """

    indexes = {0: "FL", 1: "FR", 2: "RL", 3: "RR"}
    names = {"FL": 0, "FR": 1, "RL": 2, "RR": 3}

    height_texture_id = 0
    load_texture_id = 0
    suspension_texture_id = 0
    tyre_texture_id = 0

    cx = 200
    cy = 100

    def __init__(self, wheel_index):
        """ Default constructor receive the index of the wheel it will draw info. """
        self.__id = WInfo.indexes[wheel_index]
        self.__active = bool(WConfig.get_str("Windows", self.__id))
        self.__index = wheel_index
        self.__is_left = wheel_index is 0 or wheel_index is 2
        self.__info = {}
        self.__window_id = ac.newApp("Wheel Telemetry {}".format(self.__id))
        ac.drawBorder(self.__window_id, 0)
        ac.setBackgroundOpacity(self.__window_id, 0)
        ac.setIconPosition(self.__window_id, 0, -10000)
        ac.setSize(self.__window_id, 400, 200)
        ac.setTitle(self.__window_id, "")

        if self.__id is "FL":
            ac.setPosition(self.__window_id, 200, 200)
        elif self.__id is "FR":
            ac.setPosition(self.__window_id, 1320, 200)
        elif self.__id is "RL":
            ac.setPosition(self.__window_id, 200, 400)
        else:
            ac.setPosition(self.__window_id, 1320, 400)

        self.__lb_height = ac.addLabel(self.__window_id, "- mm")
        ac.setFontAlignment(self.__lb_height, "center")
        ac.setPosition(self.__lb_height, WInfo.cx +
                       (80 if self.__is_left else -130) + 25, WInfo.cy + 20)

        lb_pressure_bg = ac.addLabel(self.__window_id, "")
        ac.setBackgroundColor(lb_pressure_bg, 0, 0, 0)
        ac.setBackgroundOpacity(lb_pressure_bg, 1)
        ac.setPosition(lb_pressure_bg, WInfo.cx - 30, WInfo.cy / 2)
        ac.setSize(lb_pressure_bg, 60, 100)

        self.__lb_pressure = ac.addLabel(self.__window_id, "- psi")
        ac.setFontAlignment(self.__lb_pressure, "center")
        ac.setPosition(self.__lb_pressure, WInfo.cx, WInfo.cy - 10)

        if WInfo.height_texture_id == 0:
            WInfo.height_texture_id = ac.newTexture(
                "apps/python/WheelTelemetry/img/height.png")
        if WInfo.load_texture_id == 0:
            WInfo.load_texture_id = ac.newTexture(
                "apps/python/WheelTelemetry/img/load.png")
        if WInfo.suspension_texture_id == 0:
            WInfo.suspension_texture_id = ac.newTexture(
                "apps/python/WheelTelemetry/img/suspension.png")
        if WInfo.tyre_texture_id == 0:
            WInfo.tyre_texture_id = ac.newTexture(
                "apps/python/WheelTelemetry/img/tyre.png")

    def __draw_suspension(self):
        pos_x = WInfo.cx + (60.0 if self.__is_left else -70.0)
        pos_y = WInfo.cy - 50.0
        ac.glColor4f(1.0, 1.0, 1.0, 1.0)
        ac.glQuad(pos_x - 1.0, pos_y - 1.0, 12.0, 102.0)
        ac.glColor4f(0.0, 0.0, 0.0, 1.0)
        ac.glQuad(pos_x, pos_y, 10.0, 100.0)

        travel = self.__info["susp_travel"]
        if travel > 0.9 or travel < 0.1:
            ac.glColor4f(1.0, 0.270, 0.0, 1.0)
        elif travel > 0.8 or travel < 0.2:
            ac.glColor4f(0.941, 0.902, 0.549, 1.0)
        else:
            ac.glColor4f(1.0, 1.0, 1.0, 1.0)
        ac.glQuad(pos_x, pos_y +
                  (100.0 * (1.0 - travel)), 10.0, 100.0 * travel)
        ac.glQuadTextured(pos_x + (10.0 if self.__is_left else -50.0),
                          WInfo.cy - 50, 50, 50, WInfo.suspension_texture_id)

    def __draw_wear(self):
        pos_x = WInfo.cx + (-42.0 if self.__is_left else 36.0)
        pos_y = WInfo.cy - 50.0
        ac.glColor4f(1.0, 1.0, 1.0, 1.0)
        ac.glQuad(pos_x - 1.0, pos_y - 1.0, 8.0, 102.0)
        ac.glColor4f(0.0, 0.0, 0.0, 1.0)
        ac.glQuad(pos_x, pos_y, 6.0, 100.0)

        wear_ratio = self.__info["wear"] if self.__info["wear"] >= 94.0 else 94.0
        wear_ratio = (wear_ratio - 94.0) / 6.0
        if self.__info["wear"] >= 98.0:
            ac.glColor4f(0.235, 0.702, 0.443, 1.0)
        elif self.__info["wear"] >= 96.0:
            ac.glColor4f(0.941, 0.902, 0.549, 1.0)
        else:
            ac.glColor4f(1.0, 0.270, 0.0, 1.0)
        ac.glQuad(pos_x, pos_y + (100.0 * (1.0 - wear_ratio)),
                  6.0, 100.0 * wear_ratio)

    def get_id(self):
        """ Returns the whhel id. """
        return self.__id

    def get_window_id(self):
        """ Returns the window id. """
        return self.__window_id

    def is_active(self):
        """ Returns window status. """
        return self.__active

    def draw(self):
        """ Draws all info on screen. """
        self.__draw_wear()
        self.__draw_suspension()

        ac.glColor4f(0.513, 0.360, 0.231, 1.0)
        ac.glQuad(WInfo.cx - 30.0, WInfo.cy + 50.0 -
                  self.__info["dirt"], 60.0, self.__info["dirt"])

        ac.glColor4f(1.0, 1.0, 1.0, 1.0)
        ac.glQuadTextured(WInfo.cx - 34.0, WInfo.cy - 54.0,
                          68.0, 108.0, WInfo.tyre_texture_id)

        ac.glBegin(acsys.GL.Quads)
        ac.glColor4f(1.0, 1.0, 1.0, 1.0)
        ac.glVertex2f(WInfo.cx - 40.0, WInfo.cy +
                      64.0 + self.__info["camber_l"])
        ac.glVertex2f(WInfo.cx - 40.0, WInfo.cy + 65.0)
        ac.glVertex2f(WInfo.cx + 40.0, WInfo.cy + 65.0)
        ac.glVertex2f(WInfo.cx + 40.0, WInfo.cy +
                      64.0 + self.__info["camber_r"])
        ac.glEnd()

        load = self.__info["load"]
        half_load = load / 2.0
        ac.glColor4f(1.0, 1.0, 1.0, 1.0)
        ac.glQuadTextured(WInfo.cx - half_load, WInfo.cy -
                          half_load, load, load, WInfo.load_texture_id)

        ac.glQuadTextured(WInfo.cx + (80.0 if self.__is_left else -130.0),
                          WInfo.cy, 50, 50, WInfo.height_texture_id)
        ac.setText(self.__lb_height, "{} mm".format(
            int(self.__info["height"] * 1000.0)))
        ac.setText(self.__lb_pressure, "{:03.1f} psi".format(
            self.__info["pressure"]))

    def set_active(self, active):
        """ Toggles the window status. """
        self.__active = active
        WConfig.set_str("Windows", self.__id, str(self.__active))

    def update(self):
        """ Updates the wheel info. """
        camber = math.sin(info.physics.camberRAD[self.__index]) * 100.0
        self.__info["camber_l"] = camber if self.__is_left else 0.0
        self.__info["camber_r"] = 0.0 if self.__is_left else camber
        self.__info["dirt"] = info.physics.tyreDirtyLevel[self.__index] * 4.0
        self.__info["height"] = info.physics.rideHeight[0 if self.__index < 2 else 1]
        self.__info["load"] = info.physics.wheelLoad[self.__index] / 12.0
        self.__info["pressure"] = info.physics.wheelsPressure[self.__index]
        self.__info["susp_travel"] = info.physics.suspensionTravel[self.__index] / \
            info.static.suspensionMaxTravel[self.__index]
        self.__info["wear"] = info.physics.tyreWear[self.__index]
