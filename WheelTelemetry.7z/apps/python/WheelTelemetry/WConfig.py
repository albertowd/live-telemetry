import configparser
import os

WHEEL_TELEMETRY_CONFIGS = configparser.ConfigParser()
if os.path.isfile("apps/python/WheelTelemetry/cfg.ini"):
    WHEEL_TELEMETRY_CONFIGS.read("apps/python/WheelTelemetry/cfg.ini")
else:
    WHEEL_TELEMETRY_CONFIGS["Windows"] = {"FL": "False", "FR": "False", "RL": "False", "RR": "False"}


def get_str(session, option):
    """ Returns an option from a session in the config file. """
    global WHEEL_TELEMETRY_CONFIGS
    return WHEEL_TELEMETRY_CONFIGS.get(session, option)


def set_str(session, option, value):
    """ Updates an option in a session in the config file. """
    global WHEEL_TELEMETRY_CONFIGS
    WHEEL_TELEMETRY_CONFIGS.set(session, option, value)

    cfg_file = open("apps/python/WheelTelemetry/cfg.ini", 'w')
    WHEEL_TELEMETRY_CONFIGS.write(cfg_file)
    cfg_file.close()
